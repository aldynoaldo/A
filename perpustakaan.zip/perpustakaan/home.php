<p></p>
<body>
    <center><font size="+3" face="arial">Sistem Informasi Perpustakaan</font></center>
    <center><font size="+3" face="arial">SD Negeri Parang Tambung I Makassar</font></center>
</body>